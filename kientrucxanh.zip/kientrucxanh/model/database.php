<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 
<?php
 
//Thực hiện kết nối đến CSDL helloworld.
$connect = mysqli_connect('localhost','root','','kientrucxanh');
 
//Nếu có lỗi xảy ra thì dừng đoạn mã và in ra thông báo lỗi.
if(mysqli_connect_errno()!==0)
{
    die("Error: Could not connect to the database. An error ".mysqli_connect_error()." ocurred.");
}
 
//Chọn hệ ký tự là utf8 để có thể in ra tiếng Việt.
mysqli_set_charset($connect,'utf8');
 
//Khởi tạo câu lệnh truy vấn.
$query = "SELECT * FROM adim";
 
//Thực hiện câu lệnh truy vấn và lấy ra kết quả.
$results = mysqli_query($connect,$query);
 
while( ($rows = mysqli_fetch_assoc($results))!= NULL )
{
    echo $rows['id_adim']." - ".$rows['name']."<br />";
}
 
//Đóng kết nối CSDL.
mysqli_close($connect);
 
?>
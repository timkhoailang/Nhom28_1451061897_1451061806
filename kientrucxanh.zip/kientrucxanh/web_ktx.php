<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="vi-vn" lang="vi-vn">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <meta name="keywords" content="kien truc, xay dung, nha xanh, kien truc xanh, moi truong, xa hoi, nang luong, sinh thai, kien truc sinh thai, xanh, ngoi nha xanh, tu van thiet ke, cam nang kien truc">
  <meta name="description" content="Kiến trúc xanh. Tư vấn thiết kế công trình xanh, cong trinh kien truc xanh, kiến trúc sinh thái thân thiện môi trường, tiết kiệm năng lượng, bảo vệ môi trường. Kiến trúc xanh - xu thế của xã hội hiện đại">
<title> Kiến trúc xanh - our homework</title>
<link rel="stylesheet" type="text/css" href="public/header.css" />
<link rel="stylesheet" type="text/css" href="public/menu.css" />
<link rel="stylesheet" type="text/css" href="public/content.css" />
<link rel="stylesheet" type="text/css" href="public/webktx.css" />
</head>

<body>
<div id="main">

	<!-- TOP : START -->
	<div id="header">
	
	
	</div>
	<!-- TOP : END -->

	<!-- MENU : START-->
	<div id="menu">
		<ul id="ja-cssmenu" class="clearfix">
		<li class="active"><a href="http://www.kientrucxanh.com/" class="menu-item0 active first-item" id="menu1" title="Kiến trúc xanh"><span class="menu-title">Kiến trúc xanh</span></a></li> 
		<li><a href="#" title="Giới thiệu"><span class="menu-title">Giới thiệu</span></a></li> 
		<li><a href="#" title="Công trình kiến trúc"><span class="menu-title">Công trình kiến trúc</span></a></li> 
		<li><a href="#" title="Thông tin kiến trúc"><span class="menu-title">Thông tin kiến trúc</span></a></li> 
		<li><a href="#" title="Cẩm nang kiến trúc"><span class="menu-title">Cẩm nang kiến trúc</span></a></li> 
		<li><a href="#" title="Tư vấn kiến trúc"><span class="menu-title">Tư vấn kiến trúc</span></a></li> 
		<li><a href="#" title="Liên hệ"><span class="menu-title">Liên hệ</span></a></li> 
		</ul>        	
	</div>
	<!-- MENU : END -->

	<!-- CONTENT : START -->
	<div id="content">
	
	<div id = "noidungchinh">
	<!-- ND CHINH : START -->

			<div id="ndtop">
			<!-- ND TOP : START -->
			<h1>Kiến trúc - Kiến trúc sinh thái - kien truc xay dung - Công ty kiến trúc</h1>
				<table cellpadding="0" cellspacing="0">
				<tbody><tr>
					<td valign="top">
									<div>
						
				<div>

				<form method="post" action="http://www.kientrucxanh.com/"><span class="content_rating">Xem kết quả:<img src="public/image/rating_starstar.png" width="12" height="12" alt="" title=""><img src="public/image/rating_starstar.png" width="12" height="12" alt="" title=""><img src="public/image/rating_starstar.png" width="12" height="12" alt="" title=""><img src="public/image/rating_starstar.png" width="12" height="12" alt="" title=""><img src="public/image/rating_starstar_blank.png" width="12" height="12" alt="" title="">&nbsp;/&nbsp; số bình chọn: 17</span>
				<br>
				<span>Bình thường<input type="radio" alt="vote 1 star" name="user_rating" value="1"><input type="radio" alt="vote 2 star" name="user_rating" value="2"><input type="radio" alt="vote 3 star" name="user_rating" value="3"><input type="radio" alt="vote 4 star" name="user_rating" value="4"><input type="radio" alt="vote 5 star" name="user_rating" value="5" checked="checked">Tuyệt vời&nbsp;<input class="button" type="submit" name="submit_vote" value="Bỏ phiếu"><input type="hidden" name="task" value="vote"><input type="hidden" name="option" value="com_content"><input type="hidden" name="cid" value="164"><input type="hidden" name="url" value="http://www.kientrucxanh.com/"></span></form><div style="display:none;"><span class="item"><span class="fn">Thư ngỏ</span></span><span ><span>4</span> .<span class="best">5</span></span>.<span class="count">17</span> -.</div>
				<div>
				<p style="text-align: justify;text-indent: 5px;">Khái niệm “kiến trúc xanh”, hay gọi cách khác là “kiến trúc bền vững” (sustainable building), được dùng để đề cập đến công tác kiến tạo các công trình kiến trúc và sử dụng những phương pháp mang tính thân thiện với môi trường và tính hiệu quả trong việc sử dụng tài nguyên thiên nhiên trong suốt “đời sống” của công trình: từ thiết kế, xây dựng, điều hành, bảo trì, cải tạo cho đến tháo dỡ. Khái niệm này được mở rộng và bổ sung thêm vào những mục tiêu của công tác thiết kế xây dựng truyền thống là kinh tế, hữu dụng, kiên cố và tiện nghi.</p></div>

				</div>
						</div>
						</td>
				</tr>

				</tbody></table>
			<!-- ND TOP : END -->
			</div>

			<div id="ndbottom">
			<!-- ND BOTTOM : START -->
			<div class="bt1">
				<h3><span>CÔNG TRÌNH KIẾN TRÚC - KIẾN TRÚC XANH</span></h3>
				<table>
					<tr class="tr1">
						<td>
							<div class="bt2">
							<a href="http://www.kientrucxanh.com/cong-trinh-kien-truc/151-carcassonne--thanh-pho-lau-dai-diem-le.html" >Carcassonne – Thành phố lâu đài diễm lệ</a><br>
							<img src="public/image/laudai.jpeg" alt="hinh1"><p style="word-spacing:3px;">Thành phố nhỏ bé Carcassonne nổi tiếng khắp thế giới bởi bộ sưu tập những tòa lâu đài cổ kính, lộng lẫy, huyền bí như trong...</p>
							</div></td>
						<td>
							<div class="bt2">
							<a href="http://www.kientrucxanh.com/cong-trinh-kien-truc/150-ngoi-nha-culver-o-chicago.html" >Ngôi nhà Culver - Ở Chicago</a><br>
							<img src="public/image/2.jpeg" alt="hinh1"><p style="word-spacing:3px;">Đồ án thiết kế gần đây trong "Giải thưởng AIA Chicago cho những thiết kế chưa đuợc xây dựng 2010", ngôi nhà Culver đã dấy lên...</p>
							</div></td>
					</tr>
					<tr class="tr1">
						<td>
							<div class="bt2">
							<a href="http://www.kientrucxanh.com/cong-trinh-kien-truc/148-cong-trinh-xanh-tay-ban-nha-va-bo-dao-nha.html" >Công trình xanh Tây Ban Nha và Bồ Đào Nha</a><br>
							<img src="public/image/3.jpeg" alt="hinh1"><p style="word-spacing:3px;">Các công trình xây dựng luôn tiêu thụ năng lượng với những con số khổng lồ. Theo số liệu tổng kết trên thế giới thì tỷ...</p>
							</div></td>
						<td>
							<div class="bt2">
							<a href="http://www.kientrucxanh.com/cong-trinh-kien-truc/147-toa-nha-lam-mat-tu-nhien-.html" >Tòa nhà làm mát tự nhiên</a><br>
							<img src="public/image/4.jpeg" alt="hinh1"><p style="word-spacing:3px;">Kiến trúc sư Wallflower đã dành được giải thưởng cao quý trong Giải thưởng Kiến trúc Thiết kế tại Singapore vì công trình kiến trúc tòa...</p>
							</div></td>
					</tr>
					<tr class="tr1">
						<td>
							<div class="bt2">
							<a href="http://www.kientrucxanh.com/cong-trinh-kien-truc/146-cong-trinh-kien-truc-xanh-o-paris-.html" >Công trình kiến trúc xanh ở Paris</a><br>
							<img src="public/image/5.jpeg" alt="hinh1"><p style="word-spacing:3px;">Công trình kiến trúc sinh thái, thân thiện môi trường mới gần đây được xây dựng ngay trung tâm của Paris, thủ đô của nước Pháp...</p>
							</div></td>
						<td>
							<div class="bt2">
							<a href="http://www.kientrucxanh.com/cong-trinh-kien-truc/145-12-cong-trinh-kien-truc-xanh-doc-dao-nhat-the-gioi-.html" >12 công trình kiến trúc xanh độc đáo nhất thế giới</a><br>
							<img src="public/image/6.jpeg" alt="hinh1"><p style="word-spacing:3px;">Đây là 12 công trình kiến trúc thân thiện môi trường và tối ưu hóa các tính năng về năng lượng cũng như bảo vệ môi...</p>
							</div></td>
					</tr>
			</table>
					
			</div>

			<div class="bt1">
					<h3><span>THÔNG TIN KIẾN TRÚC - KIẾN TRÚC SINH THÁI</span></h3>
				<table>
					<tr class="tr1">
						<td>
							<div class="bt2">
							<a href="http://www.kientrucxanh.com/thong-tin-kien-truc/142-phat-trien-kien-truc-xanh-o-viet-nam.html" >Phát triển kiến trúc xanh ở Việt Nam</a><br>
							<img src="public/image/7.jpeg" alt="hinh1"><p style="word-spacing:3px;">Trong chương trình hội thảo “Biến đổi khí hậu và phát triển đô thị bền vững tại Việt Nam” do Viện Goethe tổ chức tại Hà...</p>
							</div></td>
						<td>
							<div class="bt2">
							<a href="http://www.kientrucxanh.com/thong-tin-kien-truc/141-tiet-kiem-nang-luong-dong-hanh-voi-kien-truc-xanh-.html" >Tiết kiệm năng lượng đồng hành với kiến trúc xanh</a><br>
							<img src="public/image/8.jpeg" alt="hinh1"><p style="word-spacing:3px;">Ngày 16 - 17/8, Hội thảo “Giải pháp tiết kiệm năng lượng, ứng dụng năng lượng mới và kiến trúc xanh” do Hiệp hội kỹ sư...</p>
							</div></td>
					</tr>
					<tr class="tr1">
						<td>
							<div class="bt2">
							<a href="http://www.kientrucxanh.com/thong-tin-kien-truc/140-kien-truc-xanh-huong-toi-su-ben-vung.html" >Kiến trúc xanh hướng tới sự bền vững</a><br>
							<img src="public/image/9.jpeg" alt="hinh1"><p style="word-spacing:3px;">Trước đây, khi thiết kế và xây dựng gần như tất cả đều chưa nghĩ tới “xanh”, tới “môi trường” và các khái niệm “Kiến trúc...</p>
							</div></td>
						<td>
							<div class="bt2">
							<a href="http://www.kientrucxanh.com/thong-tin-kien-truc/139-kien-truc-xanh-cho-cac-khu-dan-cu-khu-do-thi-moi.html" >Kiến trúc xanh cho các khu dân cư, khu đô thị mới</a><br>
							<img src="public/image/10.jpeg" alt="hinh1"><p style="word-spacing:3px;">Kiến trúc xanh (green architecture), theo nghĩa rộng là xây dựng xanh (green building), biểu tượng của sự bền vững, dành cho cả các khu dân...</p>
							</div></td>
					</tr>
					<tr class="tr1">
						<td>
							<div class="bt2">
							<a href="http://www.kientrucxanh.com/thong-tin-kien-truc/138-huong-toi-kien-truc-xanh-va-hoi-nhap.html" >Hướng tới kiến trúc xanh và hội nhập</a><br>
							<img src="public/image/11.jpeg" alt="hinh1"><p style="word-spacing:3px;">Diễn ra 2 năm một lần, giải thưởng kiến trúc quốc gia (GTKTQG) do Hội Kiến trúc sư Việt Nam, Bộ Xây dựng và Bộ VH,TT&DL...</p>
							</div></td>
						<td>
							<div class="bt2">
							<a href="http://www.kientrucxanh.com/thong-tin-kien-truc/137-xay-dung-nen-kien-truc-xanh-hien-dai-va-ban-sac.html" >Xây dựng nền kiến trúc Xanh - Hiện đại và Bản sắc</a><br>
							<img src="public/image/12.jpeg" alt="hinh1"><p style="word-spacing:3px;">Thực hiện chỉ đạo của Ban Bí thư Trung ương Đảng và Quyết định của Thủ tướng Chính phủ, năm nay, lần đầu tiên Ngày Kiến..</p>
							</div></td>
					</tr>
			</table>
					
			</div>
			<!-- ND BOTTOM: END -->
			</div>

	<!-- ND CHINH : END -->
	</div>

	<div id = "noidungphu">
	<!-- ND PHU : START -->
	<div class="ndp1">
		<h3><span>CẨM NANG KIẾN TRÚC</span></h2>
		<div class="bt2">
		<a href="http://www.kientrucxanh.com/cam-nang-kien-truc/158-thi-cong-vuon-tren-mai-nha.html" >Thi công vườn trên mái nhà</a><br>
		<img src="public/image/vuon-1_45_40.jpg" alt="hinh1"><p>Một khu vườn xanh trên mái nhà ngoài việc giúp căn hộ của bạn thêm...</p><br>
		</div>
		<div class="bt2">
		<a href="http://www.kientrucxanh.com/cam-nang-kien-truc/157-nhung-ngoi-nha-cua-tuong-lai.html" >Những ngôi nhà của tương lai</a><br>
		<img src="public/image/2.jpg" alt="hinh1"><p>Những ngôi nhà dưới đây đều có thiết kế nổi bật, độc đáo,...</p><br>
		</div>
		<div class="bt2">
		<a href="http://www.kientrucxanh.com/cam-nang-kien-truc/155-khong-gian-song-tinh-te-voi-dome.html" >Không gian sống tinh tế với Dome</a><br>
		<img src="public/image/3.jpg" alt="hinh1"><p>Không gian sống có lối kiến trúc đơn giản, hiện đại kết hợp cùng...</p><br>
		</div>
		<div class="bt2">
		<a href="http://www.kientrucxanh.com/cam-nang-kien-truc/154-3-cach-giup-gian-bep-thong-thoang.html" >3 cách giúp gian bếp thông thoáng</a><br>
		<img src="public/image/4.jpg" alt="hinh1"><p>Không gian bếp là nơi hội họp lý tưởng của những bữa ăn đầm ấm...</p><br>
		</div>
		<div class="bt2">
		<a href="http://www.kientrucxanh.com/cam-nang-kien-truc/153-thiet-ke-xanh-cho-truong-hoc-.html" >Thiết kế xanh cho trường học</a><br>
		<img src="public/image/5.jpg" alt="hinh1"><p>Kiến trúc của trường THCS và PTTH Phan Chu Trinh nằm tại Dĩ An, tỉnh...</p><br>
		</div>
	</div>
	<div>
		<br>
	</div>
	<div class="ndp1">
		<h3><span>TƯ VẤN KIẾN TRÚC</span></h2>
		<div class="bt2">
		<a href="http://www.kientrucxanh.com/tu-van-kien-truc/163-tu-thiet-ke-mot-khu-vuon-xinh-.html" >Tự thiết kế một khu vườn xinh</a><br>
		<img src="public/image/6.jpg" alt="hinh1"><p>Năm bước căn bản dưới đây sẽ giúp ích cho bạn rất nhiều trong...</p><br>
		</div>
		<div class="bt2">
		<a href="http://www.kientrucxanh.com/tu-van-kien-truc/162-cho-goc-vuon-xinh-cang-them-xinh-.html" >Cho góc vườn xinh càng thêm xinh</a><br>
		<img src="public/image/7.jpg" alt="hinh1"><p>Cho góc vườn xinh càng thêm xinh</p><br>
		</div>
		
		<div class="bt2">
		<a href="http://www.kientrucxanh.com/tu-van-kien-truc/161-vuon-treo-cho-nha-dep-.html" >Vườn treo cho nhà đẹp</a><br>
		<img src="public/image/8.jpg" alt="hinh1"><p>Nếu bạn yêu thích cây xanh nhưng ngôi nhà của bạn không còn khoảng...</p><br>
		</div>

		<div class="bt2">
		<a href="http://www.kientrucxanh.com/tu-van-kien-truc/160-la-phoi-xanh-cho-ngoi-nha.html" >Lá phổi xanh cho ngôi nhà</a><br>
		<img src="public/image/9.jpg" alt="hinh1"><p>Để thanh lọc không khí cho ngôi nhà của bạn, chỉ vài chậu cây cảnh...</p><br>
		</div>

		<div class="bt2">
		<a href="http://www.kientrucxanh.com/tu-van-kien-truc/159-huong-va-sac-khu-vuon-theo-phong-thuy-.html" >Hương và sắc khu vườn theo phong thủy</a><br>
		<img src="public/image/10.jpg" alt="hinh1"><p>Chúng ta phản ứng với khu vườn của mình thông qua cảm xúc và các giác...</p><br>
		</div>
	</div>

	<div>
		<br>
	</div>

	<div class="ndp1">
		<h3><span>THỐNG KÊ TRUY CẬP</span></h2>
		<p style="text-align: center;">Hiện có 3 khách hàng trực tuyến</p>
	</div>
	
	<!-- ND PHU: END -->
	</div>
<!-- CONTENT : END -->
</div>
	
	<div style="clear:left;"></div>
	<!-- FOOTER : START -->
	<div id="footer">
		<div style="text-align: center;">Copyright © 2011 <strong><a href="http://www.kientrucxanh.com/"><font color="#CBE731">Kiến trúc</font></a> - <a href="http://www.kientrucxanh.com/"><font color="#CBE731">Kiến trúc xanh</font></a> - <a href="http://www.kientrucxanh.com/"><font color="#CBE731">Kiến trúc sinh thái</font></a> - <a href="http://www.kientrucxanh.com/"><font color="#CBE731">kien truc xay dung</font></a> - <a href="http://www.kientrucxanh.com/"><font color="#CBE731">Công ty kiến trúc</font></a></strong>. Phát triển bởi <a href="http://www.thietkewebsitedep.com/" target="_blank"><font color="#CBE731">Thiết Kế Website</font></a> Đẹp</div>
		<div style="text-align: center;">
		Thông tin trên web chỉ là tham khảo. Chúng tôi chưa cung cấp thông tin hoặc dịch vụ trên website này
		</div>	
	</div>
	<!-- FOOTER : END -->
</div>
</body>

</html>